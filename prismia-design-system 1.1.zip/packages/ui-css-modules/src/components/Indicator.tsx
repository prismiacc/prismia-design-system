import React from 'react';
import styles from '../styles/Indicator.module.css';

export interface IndicatorProps {
  children: React.ReactNode;
  status?: 'online' | 'offline' | 'busy' | 'away';
  count?: number;
  dot?: boolean;
}

export const Indicator: React.FC<IndicatorProps> = ({ 
  children, 
  status,
  count,
  dot = false
}) => {
  const showBadge = status || count !== undefined || dot;

  return (
    <div className={styles.indicator}>
      {children}
      {showBadge && (
        <span className={`${styles.indicator__badge} ${status ? styles[`indicator__badge--${status}`] : ''}`}>
          {!dot && count !== undefined && (count > 99 ? '99+' : count)}
        </span>
      )}
    </div>
  );
};