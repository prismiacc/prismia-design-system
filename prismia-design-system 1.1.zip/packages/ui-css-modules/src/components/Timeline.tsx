import React from 'react';
import styles from '../styles/Timeline.module.css';

export interface TimelineItem {
  title: string;
  time?: string;
  description?: string;
  color?: 'default' | 'success' | 'error' | 'warning';
}

export interface TimelineProps {
  items: TimelineItem[];
}

export const Timeline: React.FC<TimelineProps> = ({ items }) => {
  return (
    <div className={styles.timeline}>
      {items.map((item, index) => (
        <div key={index} className={styles.timeline__item}>
          <div className={`${styles.timeline__dot} ${item.color ? styles[`timeline__dot--${item.color}`] : ''}`} />
          <div className={styles.timeline__content}>
            <div className={styles.timeline__header}>
              <h4 className={styles.timeline__title}>{item.title}</h4>
              {item.time && <span className={styles.timeline__time}>{item.time}</span>}
            </div>
            {item.description && <p className={styles.timeline__description}>{item.description}</p>}
          </div>
        </div>
      ))}
    </div>
  );
};