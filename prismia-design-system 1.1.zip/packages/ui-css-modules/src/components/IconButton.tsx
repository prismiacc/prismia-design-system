import React from 'react';
import styles from '../styles/IconButton.module.css';

export interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  variant?: 'default' | 'primary' | 'danger';
  size?: 'small' | 'medium' | 'large';
}

export const IconButton: React.FC<IconButtonProps> = ({ 
  children, 
  variant = 'default',
  size = 'medium',
  ...props 
}) => {
  return (
    <button
      className={`${styles.iconButton} ${styles[`iconButton--${variant}`]} ${styles[`iconButton--${size}`]}`}
      {...props}
    >
      {children}
    </button>
  );
};