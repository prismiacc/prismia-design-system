import React, { useState } from 'react';
import styles from '../styles/Accordion.module.css';

export interface AccordionItem {
  title: string;
  content: React.ReactNode;
}

export interface AccordionProps {
  items: AccordionItem[];
  allowMultiple?: boolean;
}

export const Accordion: React.FC<AccordionProps> = ({ items, allowMultiple = false }) => {
  const [openItems, setOpenItems] = useState<number[]>([]);

  const toggleItem = (index: number) => {
    if (allowMultiple) {
      setOpenItems(prev =>
        prev.includes(index) ? prev.filter(i => i !== index) : [...prev, index]
      );
    } else {
      setOpenItems(prev => (prev.includes(index) ? [] : [index]));
    }
  };

  return (
    <div className={styles.accordion}>
      {items.map((item, index) => (
        <div key={index} className={styles.accordion__item}>
          <button
            className={styles.accordion__trigger}
            onClick={() => toggleItem(index)}
            aria-expanded={openItems.includes(index)}
          >
            <span>{item.title}</span>
            <svg
              className={`${styles.accordion__icon} ${openItems.includes(index) ? styles['accordion__icon--open'] : ''}`}
              width="16"
              height="16"
              viewBox="0 0 16 16"
              fill="none"
            >
              <path d="M4 6l4 4 4-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
          {openItems.includes(index) && (
            <div className={styles.accordion__content}>{item.content}</div>
          )}
        </div>
      ))}
    </div>
  );
};