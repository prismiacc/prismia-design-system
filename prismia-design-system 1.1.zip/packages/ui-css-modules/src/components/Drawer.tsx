import React from 'react';
import styles from '../styles/Drawer.module.css';

export interface DrawerProps {
  open: boolean;
  onClose: () => void;
  children: React.ReactNode;
  placement?: 'left' | 'right' | 'top' | 'bottom';
}

export const Drawer: React.FC<DrawerProps> = ({ 
  open, 
  onClose, 
  children,
  placement = 'right'
}) => {
  if (!open) return null;

  return (
    <>
      <div className={styles.drawer__overlay} onClick={onClose} />
      <div className={`${styles.drawer} ${styles[`drawer--${placement}`]}`}>
        {children}
      </div>
    </>
  );
};