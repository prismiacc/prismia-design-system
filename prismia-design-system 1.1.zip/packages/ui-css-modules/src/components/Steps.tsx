import React from 'react';
import styles from '../styles/Steps.module.css';

export interface StepItem {
  title: string;
  description?: string;
}

export interface StepsProps {
  items: StepItem[];
  current?: number;
  direction?: 'horizontal' | 'vertical';
}

export const Steps: React.FC<StepsProps> = ({ 
  items, 
  current = 0,
  direction = 'horizontal'
}) => {
  return (
    <div className={`${styles.steps} ${styles[`steps--${direction}`]}`}>
      {items.map((item, index) => (
        <div 
          key={index}
          className={`${styles.steps__item} ${index === current ? styles['steps__item--active'] : ''} ${index < current ? styles['steps__item--completed'] : ''}`}
        >
          <div className={styles.steps__circle}>{index + 1}</div>
          <div className={styles.steps__content}>
            <div className={styles.steps__title}>{item.title}</div>
            {item.description && <div className={styles.steps__description}>{item.description}</div>}
          </div>
        </div>
      ))}
    </div>
  );
};