import React from 'react';
import styles from '../styles/Stepper.module.css';

export interface StepperProps {
  value: number;
  onChange: (value: number) => void;
  min?: number;
  max?: number;
  step?: number;
  disabled?: boolean;
}

export const Stepper: React.FC<StepperProps> = ({ 
  value, 
  onChange,
  min = 0,
  max = 100,
  step = 1,
  disabled = false
}) => {
  const handleDecrement = () => {
    onChange(Math.max(min, value - step));
  };

  const handleIncrement = () => {
    onChange(Math.min(max, value + step));
  };

  return (
    <div className={styles.stepper}>
      <button
        onClick={handleDecrement}
        disabled={disabled || value <= min}
        className={styles.stepper__button}
      >
        −
      </button>
      <input
        type="number"
        value={value}
        onChange={(e) => onChange(parseInt(e.target.value) || min)}
        disabled={disabled}
        className={styles.stepper__input}
      />
      <button
        onClick={handleIncrement}
        disabled={disabled || value >= max}
        className={styles.stepper__button}
      >
        +
      </button>
    </div>
  );
};