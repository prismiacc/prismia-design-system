import type { Preview } from '@storybook/react';
import '@prismia/tokens/css';

const preview: Preview = {
  parameters: {
    actions: { argTypesRegex: '^on[A-Z].*' },
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/,
      },
    },
    backgrounds: {
      default: 'prismia',
      values: [
        {
          name: 'prismia',
          value: 'var(--semantic-background-primary)',
        },
        {
          name: 'white',
          value: '#FFFFFF',
        },
        {
          name: 'dark',
          value: '#1A1A1C',
        },
      ],
    },
  },
};

export default preview;